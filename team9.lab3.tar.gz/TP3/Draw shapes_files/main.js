(function () {
  /*
   * Utils
   */
  function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }


  /*
   * Class constructors
   */
  function Point(x, y) {
    this.x = x || 0;
    this.y = y || 0;

    this.setToRandomPosition = function (maxX, maxY) {
      this.x = getRandomInt(0, maxX);
      this.y = getRandomInt(0, maxY);
    };
  }

  function Shape() {
    this.color = 'black';
    this.points = [];

    this.draw = function (context) {
      context.fillStyle = this.color;
      context.beginPath();

      this.points.forEach(function (point, index, points) {
        if (index === 0) {
          context.moveTo(point.x, point.y);

        } else {
          context.lineTo(point.x, point.y);
        }

        if (index === points.length - 1) {
          context.fill();
        }
      });
    };

    this.generatePoints = function (options) {
      for (var i = 0; i < options.numberOfPoints; i++) {
        var point = new Point();
        point.setToRandomPosition(options.maxWidth, options.maxHeight);
        this.points.push(point);
      }

      if (options.shouldSort) {
        this.sortPoints();
      }
    };

    this.sortPoints = function () {
      function lineDistance(point1, point2) {
        var xs = point2.x - point1.x;
        var ys = point2.y - point1.y;

        xs = xs * xs;
        ys = ys * ys;
        return Math.sqrt(xs + ys);
      }

      // calculate max and min x and y
      var minX = this.points[0].x;
      var maxX = this.points[0].x;
      var minY = this.points[0].y;
      var maxY = this.points[0].y;

      for (var i = 1; i < this.points.length; i++) {
        if (this.points[i].x < minX) minX = this.points[i].x;
        if (this.points[i].x > maxX) maxX = this.points[i].x;
        if (this.points[i].y < minY) minY = this.points[i].y;
        if (this.points[i].y > maxY) maxY = this.points[i].y;
      }


      // choose a "central" point
      var center = {
        x: minX + (maxX - minX) / 2,
        y: minY + (maxY - minY) / 2
      };

      // precalculate the angles of each point to avoid multiple calculations on sort
      for (var j = 0; j < this.points.length; j++) {
        this.points[j].angle = Math.acos((this.points[j].x - center.x) / lineDistance(center, this.points[j]));

        if (this.points[j].y > center.y) {
          this.points[j].angle = Math.PI + Math.PI - this.points[j].angle;
        }
      }

      // sort by angle
      this.points = this.points.sort(function (a, b) {
        return a.angle - b.angle;
      });
    };
  }


  function Rectangle(){
    this.__proto__ = new Shape();
    this.generatePoints = function(options){
      var point = new Point();
      point.setToRandomPosition(options.maxWidth, options.maxHeight);
      this.points.push(point);
      var point2 = new Point(point.x + options.width, point.y);
      if(point2.x > options.maxWidth){
        point2.x = options.maxWidth;
      }
      var point3 = new Point(point2.x, point2.y + options.height);
      if(point3.y > options.maxHeight){
        point3.y = options.maxHeight;
      }
      var point4 = new Point(point.x, point3.y);
      this.points.push(point2);
      this.points.push(point3);
      this.points.push(point4);
    }
  }

  function Square(){
    this.__proto__ = new Rectangle();
  }

  function Circle(radius){
    this.__proto__ = new Shape();
    this.radius = 25;
    this.generatePoints = function(options){
      this.radius = options.radius;
      var randomPoint = new Point();
      randomPoint.setToRandomPosition(options.maxWidth, options.maxHeight);
      if((randomPoint.x - this.radius) < 0){
        this.radius = randomPoint.x;
      }
      if((randomPoint.x + this.radius) > options.maxWidth){
        this.radius = options.maxWidth - randomPoint.x;
      }

      if((randomPoint.y - this.radius) < 0){
        this.radius = randomPoint.y;
      }
      if((randomPoint.y + this.radius) > options.maxHeight){
        this.radius = options.maxHeight - randomPoint.y;
      }

      this.points.push(randomPoint);
    }
    this.draw = function(context){
      context.fillStyle = this.color;
      context.beginPath();
      context.arc(this.points[0].x, this.points[0].y, this.radius, 0, 2 * Math.PI, false);
      context.fill();
    }
  }


  /*
   * Core of the app
   */
  function drawShapeHandler() {
    var canvasElement = document.getElementById('draw-area');

    if (!canvasElement.getContext) {
      return;
    }

    var colorInput = document.getElementById('color-input');
    var mode = document.querySelector('input[name="mode"]:checked').value;
    var ctx = canvasElement.getContext('2d');

    var shape = createShape(mode, canvasElement);
    shape.color = colorInput.value;

    shape.draw(ctx, true);
  }

  function createShape(mode, canvas) {
    var pointsInput = document.getElementById('points-input');
    var isRandomInput = document.getElementById('is-random-input');
    var numberOfPoints = parseInt(pointsInput.value);

    var options = {
      maxWidth: canvas.offsetWidth,
      maxHeight: canvas.offsetHeight,
      numberOfPoints: numberOfPoints,
      shouldSort: !isRandomInput.checked
    };

    var shape;
    switch(mode){
      case 'rectangle':
        options.width = parseInt(document.getElementById('rect-width-input').value);
        options.height = parseInt(document.getElementById('rect-height-input').value);
        shape = new Rectangle();
        break;
      case 'square' :
        var squareWidth = parseInt(document.getElementById('square-width-input').value);
        options.width = squareWidth;
        options.height = squareWidth;
        shape = new Square();
        break;
      case 'circle':
        options.radius = parseInt(document.getElementById('circle-radius-input').value);
        shape = new Circle();
        break;
      default:
        shape = new Shape();
        break;
    }
    shape.generatePoints(options);
    return shape;
  }

  document.getElementById('draw-button').addEventListener('click', drawShapeHandler);
})();

(function canvasUtils() {
  function redraw() {
    var canvas = document.getElementById('draw-area');
    canvas.width = canvas.parentElement.offsetWidth - 15;
    canvas.height = canvas.parentElement.offsetHeight - 15;
  }

  redraw();
  window.addEventListener('resize', redraw);

  function resetCanvas() {
    var canvasElement = document.getElementById('draw-area');

    if (!canvasElement.getContext) {
      return;
    }
    var context = canvasElement.getContext('2d');
    context.clearRect(0, 0, canvasElement.width, canvasElement.height);

  }

  document.getElementById('reset-button').addEventListener('click', resetCanvas);
})();
