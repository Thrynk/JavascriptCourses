const express = require('express');
var app = express();

const gifService = require('./gif-service.js');

const randomService = require('./random-gif-service.js');

var bodyParser = require('body-parser');

app.use(bodyParser.json());

app.use(bodyParser.urlencoded({extended: true}));

var expressMongoDb = require('express-mongo-db');

app.use(expressMongoDb('mongodb://isencir2:2ricnesi@ds125423.mlab.com:25423/isen-tp-5'));

app.use(express.static(__dirname + '/public'));

app.get('/', function(req, res){
  res.redirect("gif-it.html");
  /*res.sendFile("gif-it.html", {root: __dirname + '/public'});*/
});

app.get('/random/gif', function(req, res){
  randomService.getARandomGIF().then(function(data){
    res.json(data);
  });
  /*res.json({"url": "https://media.giphy.com/media/jSxK33dwEMbkY/giphy.gif"});*/
});

app.get('/gif', function(req, res){
  /*res.json({
    "results": [
      {
        "name": "Stinson suicide",
        "url": "https://media.giphy.com/media/jSxK33dwEMbkY/giphy.gif"
      },
      {
        "name": "happy stinson",
        "url": "https://media.giphy.com/media/KZxWhsC9Sk8UM/giphy.gif"
      },
      {
        "name": "Barney spits",
        "url": "https://media.giphy.com/media/Hqk5KCMTwTF3W/giphy.gif"
      },
      {
        "name": "Stinson please",
        "url": "https://media.giphy.com/media/xMCy542wMwnBK/giphy.gif"
      },
      {
        "name": "Barney high five",
        "url": "https://media.giphy.com/media/mHEes6Quf8XK0/giphy.gif"
      },
      {
        "name": "Barney magic trick",
        "url": "https://media.giphy.com/media/sRirXOIam0U00/giphy.gif"
      },
      {
        "name": "Barney highest high five request",
        "url": "https://media.giphy.com/media/QN6NnhbgfOpoI/giphy.gif"
      },
      {
        "name": "Barney dibs",
        "url": "https://media.giphy.com/media/6PDqnnPpJDIvm/giphy.gif"
      }
    ]
  });*/

  gifService.findAll(req.db).then(function(gifs){
    res.json({results: gifs});
  });
});

//POST routes
app.post('/gif', function(req, res){
  var gif = req.body;
  gifService.findAll(req.db).then(function(docs){
    if(docs.length < 9){
      gifService.saveOne(gif, req.db).then(function(id){
        res.json(id);
      });
    }
    else{
      res.json({id: "Trop de gifs"});
    }
  });

});

//DELETE routes
app.delete('/gif/:id', function(req, res){
  gifService.deleteOne(req.params.id, req.db).then(function(){
    res.sendStatus(200);
  });
});

app.listen(3000, function(){
  console.log("Listening on port 3000");
});
