const node_fetch = require('node-fetch');
module.exports = {
  getARandomGIF: function(){
    return node_fetch('https://api.giphy.com/v1/gifs/random?api_key=dc6zaTOxFJmzC&tag=fail&rating=pg-13')
      .then(function(response){
        return response.json();
      })
      .then(function(json){
        return {"url": json.data.image_url};
      });
  }
};
