(function(){
  var xhr = new XMLHttpRequest();

  xhr.open('GET', '/public/myokom-help.html');

  var help = document.getElementsByClassName("help")[0];
  var displayHelp = document.getElementsByClassName("display-help")[0];

  displayHelp.addEventListener("click", function(){
    xhr.send();
  });


  xhr.onload = function(){
    help.innerHTML = xhr.response;
    var closeButton = document.getElementsByClassName("close-help")[0];
    closeButton.addEventListener("click", function(){
      help.remove();
    });
  }

  window.onload = browseFromUrl;

  function browseFromUrl(event){
    var pageUrl = '/browse/' + window.location.href.replace("http://localhost:8080/", "");
    fetch(pageUrl)
      .then(function(response){
        return response.json();
      })
      .then(function(information){
        var trackList = $(".track-list").eq(0);
        information.dirs.forEach(function(directory){
          var dirElement = $("<a class='dir' href='" + directory.path + "/'>" + directory.name + "</a>");
          trackList.append(dirElement);
        });
        for(var i = 0; information.tracks.length; i++){
          var track = information.tracks[i];
          var trackElement = $("<button class='track' data-track-idx='" + i + "'><span class='track-name'>" + track.name + "</span></button>");
          trackList.append(trackElement);
          $(".track").eq(i).on("click", function(event){
            var index = event.currentTarget.getAttribute("data-track-idx");
            playAMusic(information.tracks[index]);
          });
        }
      });
  }

  function playAMusic(track = null){
    var player = document.getElementsByClassName("player")[0];
    var currentTrackDiv = $(".current-track").eq(0);
    if(track === null){
      if(player.getAttribute("src") === ""){
        $.get(window.location.href.replace("http://localhost:8080", "/browse"), function(data){
          var randomMusic = data.tracks[Math.floor(Math.random()*data.tracks.length)];
          player.setAttribute("src", randomMusic.path);
          currentTrackDiv.find(".track-title").text(randomMusic.name);
          player.play();
        });
      }
      else{
        player.play();
      }
    }
    else{
      player.setAttribute("src", track.path);
      currentTrackDiv.find(".track-title").text(track.name);
      player.play();
    }
    currentTrackDiv.attr("data-status", "play");
  }

  document.getElementsByClassName("track-list")[0].addEventListener("click", function(event){
    if(event.target && event.target.nodeName == "A"){
      event.preventDefault();
      window.history.pushState(null, "", event.target.href);
      document.getElementsByClassName("track-list")[0].innerHTML = "";
      browseFromUrl();
    }
  });

  window.onpopstate = function(event){
    document.getElementsByClassName("track-list")[0].innerHTML = "";
    browseFromUrl();
  };

  $(".track-control[data-action=\"play\"]").click(function(event){
    playAMusic();
  });
  $(".track-control[data-action=\"pause\"]").click(function(event){
    var player = document.getElementsByClassName("player")[0];
    player.pause();
    var currentTrackDiv = $(".current-track").eq(0);
    currentTrackDiv.attr("data-status", "pause");
  });
})();
