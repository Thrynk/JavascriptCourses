var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

var days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

var calendar = document.getElementsByClassName("calendar")[0]; /* Sélectionne l'élément <div class="calendar"></div> */

function numberOfDays(month, year){
  var nbrOfDays = 0;

  if(month <= 7){
    if(month % 2 == 1){
        nbrOfDays = 31;
    }
    else{
      nbrOfDays = 30;
    }
  }
  else{
    if(month % 2 == 1){
      nbrOfDays = 30;
    }
    else{
      nbrOfDays = 31;
    }
  }

  if(month == 2){
    if(year % 4 == 0){
      if(year % 100 == 0){
        if(year % 400 == 0){
          nbrOfDays = 29;
        }
        else{
          nbrOfDays = 28;
        }
      }
      else{
        nbrOfDays = 29;
      }
    }
    else{
      nbrOfDays = 28;
    }

  }

  return nbrOfDays;

}

function createDivMonth(date){
  var myDiv = document.createElement("div"); /* Crée un élément div */
  myDiv.classList.add("cal-month"); /* Ajoute la class cal-month à l'élément div */
  myDiv.setAttribute("data-month", (date.getUTCMonth() + i) % 12); /* donne le bon numéro de mois à l'attribut data-month */
  if(date.getUTCMonth() + i > 11){ /* Donne la bonne année */
    myDiv.setAttribute("data-year", date.getUTCFullYear() + 1);
  }
  else{
    myDiv.setAttribute("data-year", date.getUTCFullYear());
  }
  return myDiv;
}

function createH2AndAddtoMyDiv(date, myDiv){
  var myH2 = myDiv.appendChild(document.createElement("h2")); /* Crée un élément h2 */
  myH2.classList.add("cal-month-name"); /* lui ajoute la class cal-month-name */

  if(date.getUTCMonth() + i > 11){ /* Bon mois au h2 */
    myH2.textContent = months[(date.getUTCMonth() + i) % 12] + " " + (date.getUTCFullYear() + 1);
  }
  else{
    myH2.textContent = months[(date.getUTCMonth() + i) % 12] + " " + date.getUTCFullYear();
  }
  return myH2;
}

function createLi(date){
  var myLi = document.createElement("li"); /* Crée un élément li */
  myLi.classList.add("month-name"); /* ajoute class month-name */

  if(date.getUTCMonth() + i > 11){ /* Bon mois au h2 et li */
    myLi.textContent = months[(date.getUTCMonth() + i) % 12] + " " + (date.getUTCFullYear() + 1);
  }
  else{
    myLi.textContent = months[(date.getUTCMonth() + i) % 12] + " " + date.getUTCFullYear();
  }
  return myLi;
}

function createDivDayNames(){
  var divDayNames = $("<div class='day-names'></div>"); /* Crée un nouvel élément jquery */
  $(".cal-month").eq(i).append(divDayNames); /* L'ajoute à chaque cal-month */
  for(var j = 0;j < 7; j++){ /* Ajoute les 7 jours à chaque div day-names */
    divDayNames.append($("<div class='day-name'></div>").text(days[j]));
  }
}

function createDivDays(date){
  var divDays = $("<div class='days'></div>");
  $(".cal-month").eq(i).append(divDays);
  if(date.getUTCMonth() + i > 11){
    var dateFirstDay = new Date(date.getUTCFullYear()+1, (date.getUTCMonth() + i) % 12, 1);
    for(var k = 1; k <= numberOfDays( (date.getUTCMonth() + i) % 12 + 1 , date.getUTCFullYear() + 1); k++){
      var divDay = $("<div class='day' data-day='" + k + "'></div>");
      divDays.append(divDay);
      divDay.append($("<div class='day-number'>" + k + "</div>"));
    }
  }
  else{
    var dateFirstDay = new Date(date.getUTCFullYear(), (date.getUTCMonth() + i) % 12, 1);
    for(var k = 1; k <= numberOfDays( (date.getUTCMonth() + i) % 12 + 1 , date.getUTCFullYear() ); k++){
      var divDay = $("<div class='day' data-day='" + k + "'></div>");
      divDays.append(divDay);
      divDay.append($("<div class='day-number'>" + k + "</div>"));
    }
  }

  return dateFirstDay;
}

var date = new Date(); /* Date du jour */

for(var i = 0; i < 6; i++){

  var myDiv = createDivMonth(date);

  var myH2 = createH2AndAddtoMyDiv(date, myDiv);

  var myLi = createLi(date);

  calendar.appendChild(myDiv); /* met la div dans la div calendar */
  document.getElementsByClassName("months")[0].appendChild(myLi); /* met le li dans la liste ul months */

  createDivDayNames();

  var dateFirstDay = createDivDays(date);

  myDiv.setAttribute("data-day-start", dateFirstDay.getDay());

}
