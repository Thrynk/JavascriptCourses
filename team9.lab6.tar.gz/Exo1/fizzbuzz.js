function fizzbuzz(number){
  var result = "";
  if(number === undefined){
    return result;
  }
  if(number % 3 !== 0 && number % 5 !== 0){
    result += number;
  }
  while(number % 3 === 0 || number % 5 === 0){
    if(number % 3 === 0){
      result += "fizz";
      number /= 3;
    }
    if(number % 5 === 0){
      result += "buzz";
      number /= 5;
    }
  }
  return result;
}

module.exports = {
  fizzbuzz,
}
