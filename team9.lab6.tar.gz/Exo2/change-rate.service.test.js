const changeRateService = require('./change-rate.service');

describe("change rate service", function(){
  changeRateService.getChangeRates = jest.fn(function(sourceCurrency){
    return Promise.resolve({
      "base": "EUR",
      "rates": {
        "CAD": 1.4931,
        "PHP": 59.41,
        "HRK": 7.4038,
        "NOK": 9.6893,
        "USD": 1.1332,
        "THB": 37.152,
        "SEK": 10.2355,
        "CNY": 7.8074,
        "CHF": 1.1323,
        "INR": 79.791
      }
    });
  });
  it("returns USD change rate when called with EUR USD", function(){
    expect.assertions(1);
    return expect(changeRateService.getChangeRate("EUR", "USD")).resolves.toBe(1.1332);
  });
});
