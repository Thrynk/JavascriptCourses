(function(){
  fetch("/dwarfs").then(function(response){
    return response.json();
  }).then(function(data){
    nains = data.nains;
    console.log(nains);

    var mainImg = document.getElementsByClassName("mainImg")[0];
    var mainFigCaption = document.getElementsByClassName("mainFigCaption")[0];
    mainImg.setAttribute("src", nains[0].url);
    mainFigCaption.innerText = nains[0].name;

    nains.forEach(function(nain){
      var li = document.createElement("li");
      var figure = document.createElement("figure");
      li.appendChild(figure);

      var img = document.createElement("img");
      img.setAttribute("src", nain.url);
      img.setAttribute("alt", nain.name);
      figure.appendChild(img);

      var figCaption = document.createElement("figcaption");
      figCaption.innerText = nain.name;
      figure.appendChild(figCaption);

      var list = document.getElementsByTagName("ul")[0];
      list.appendChild(li);

      li.addEventListener("click", function(event){
        var mainImg = document.getElementsByClassName("mainImg")[0];
        var mainFigCaption = document.getElementsByClassName("mainFigCaption")[0];
        mainImg.setAttribute("src", event.currentTarget.childNodes[0].childNodes[0].src);
        mainFigCaption.innerText = event.currentTarget.childNodes[0].childNodes[1].innerText;
      });
    });

  });



})();
