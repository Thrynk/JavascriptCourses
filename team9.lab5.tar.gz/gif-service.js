const collectionName = 'team29';

var ObjectId = require('mongodb').ObjectID;

module.exports = {
  findAll: function(db){
    return db.collection(collectionName).find().toArray();
  },

  saveOne: function(gifReference, db){
    return db.collection(collectionName).insert(gifReference).then(function (data) {
        return { id: data.ops[0]._id };
    }, function (err) {
      throw err;
    });
  },

  deleteOne: function(id, db) {
    return db.collection(collectionName).remove({'_id': new ObjectId(id)});
  }
};
