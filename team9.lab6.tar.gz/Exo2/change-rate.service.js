const node_fetch = require('node-fetch');

function getChangeRates(sourceCurrency){
  return node_fetch("https://api.exchangeratesapi.io/latest?base=" + sourceCurrency).then(function(response){
    return response.json();
  })
  .then(function(json){
    return Promise.resolve(json);
  });
}

function getChangeRate(sourceCurrency, destinationCurrency){
  return this.getChangeRates(sourceCurrency).then(function(json){
    return Promise.resolve(json.rates[destinationCurrency]);
  });
}

module.exports = {
  getChangeRates,
  getChangeRate
};
