const express = require('express');

var app = express();

app.use(express.static(__dirname + '/public'));

app.get("/", function(req, res){
  res.redirect("dwarfs-list.html");
});

app.get("/dwarfs", function(req, res){
  res.sendFile("dwarfs.json", {root: __dirname});
});

app.listen(3000, function(){
  console.log("listening on port 3000");
});
