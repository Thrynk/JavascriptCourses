const changeRateService = require('./change-rate.service');

function convert(amount, sourceCurrency, destinationCurrency){
  if(typeof amount !== "number"){
    return Promise.reject("Amount should be a number");
  }
  return changeRateService.getChangeRate(sourceCurrency, destinationCurrency).then(function(changeRate){
    return Promise.resolve(amount * changeRate);
  }).catch(function(error){
    return Promise.reject(error);
  });
}

module.exports = {
  convert
};
