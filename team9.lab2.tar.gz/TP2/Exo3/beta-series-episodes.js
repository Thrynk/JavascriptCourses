var tvShows = {
  series: [
    {
      name: 'Better Call Saul',
      ref: 'better-call-saul',
      seasons: [
        {
          number: 4,
          episodes: [
            {
              number: 5,
              date: '09/04/2018'
            },
            {
              number: 6,
              date: '09/11/2018'
            },
            {
              number: 7,
              date: '09/18/2018'
            },
            {
              number: 8,
              date: '09/25/2018'
            },
            {
              number: 9,
              date: '10/02/2018'
            },
            {
              number: 10,
              date: '10/09/2018'
            }
          ]
        }
      ]
    },
    {
      name: 'Marvel\'s Iron Fist',
      ref: 'marvels-iron-fist',
      seasons: [
        {
          number: 2,
          episodes: [
            {
              number: 1,
              date: '09/07/2018'
            },
            {
              number: 2,
              date: '09/07/2018'
            },
            {
              number: 3,
              date: '09/07/2018'
            },
            {
              number: 4,
              date: '09/07/2018'
            },
            {
              number: 5,
              date: '09/07/2018'
            },
            {
              number: 6,
              date: '09/07/2018'
            },
            {
              number: 7,
              date: '09/07/2018'
            },
            {
              number: 8,
              date: '09/07/2018'
            },
            {
              number: 9,
              date: '09/07/2018'
            },
            {
              number: 10,
              date: '09/07/2018'
            }
          ]
        }
      ]
    },
    {
      name: 'BoJack Horseman',
      ref: 'bojack-horseman',
      seasons: [
        {
          number: 5,
          episodes: [
            {
              number: 1,
              date: '09/14/2018'
            },
            {
              number: 2,
              date: '09/14/2018'
            },
            {
              number: 3,
              date: '09/14/2018'
            },
            {
              number: 4,
              date: '09/14/2018'
            },
            {
              number: 5,
              date: '09/14/2018'
            },
            {
              number: 6,
              date: '09/14/2018'
            },
            {
              number: 7,
              date: '09/14/2018'
            },
            {
              number: 8,
              date: '09/14/2018'
            },
            {
              number: 9,
              date: '09/14/2018'
            },
            {
              number: 10,
              date: '09/14/2018'
            },
            {
              number: 11,
              date: '09/14/2018'
            },
            {
              number: 12,
              date: '09/14/2018'
            }
          ]
        }
      ]
    },
    {
      name: 'Big Bang Theory',
      ref: 'big-bang-theory',
      seasons: [
        {
          number: 12,
          episodes: [
            {
              number: 1,
              date: '09/25/2018'
            },
            {
              number: 2,
              date: '09/28/2018'
            },
            {
              number: 3,
              date: '10/05/2018'
            },
            {
              number: 4,
              date: '10/12/2018'
            }
          ]
        }
      ]
    },
    {
      name: 'Young Sheldon',
      ref: 'young-sheldon',
      seasons: [
        {
          number: 2,
          episodes: [
            {
              number: 1,
              date: '09/25/2018'
            },
            {
              number: 2,
              date: '09/28/2018'
            },
            {
              number: 3,
              date: '10/05/2018'
            },
            {
              number: 4,
              date: '10/12/2018'
            }
          ]
        }
      ]
    },
    {
      name: 'House Of Cards (US)',
      ref: 'house-of-cards',
      seasons: [
        {
          number: 6,
          episodes: [
            {
              number: 1,
              date: '11/02/2018'
            },
            {
              number: 2,
              date: '11/02/2018'
            },
            {
              number: 3,
              date: '11/02/2018'
            },
            {
              number: 4,
              date: '11/02/2018'
            },
            {
              number: 5,
              date: '11/02/2018'
            },
            {
              number: 6,
              date: '11/02/2018'
            },
            {
              number: 7,
              date: '11/02/2018'
            },
            {
              number: 8,
              date: '11/02/2018'
            }
          ]
        }
      ]
    },
    {
      name: 'Marvel\'s Daredevil',
      ref: 'marvels-daredevil',
      seasons: [
        {
          number: 3,
          episodes: [
            {
              number: 1,
              date: '10/19/2018'
            },
            {
              number: 2,
              date: '10/19/2018'
            },
            {
              number: 3,
              date: '10/19/2018'
            },
            {
              number: 4,
              date: '10/19/2018'
            },
            {
              number: 5,
              date: '10/19/2018'
            },
            {
              number: 6,
              date: '10/19/2018'
            },
            {
              number: 7,
              date: '10/19/2018'
            },
            {
              number: 8,
              date: '10/19/2018'
            },
            {
              number: 9,
              date: '10/19/2018'
            },
            {
              number: 10,
              date: '10/19/2018'
            },
            {
              number: 11,
              date: '10/19/2018'
            },
            {
              number: 12,
              date: '10/19/2018'
            },
            {
              number: 13,
              date: '10/19/2018'
            }
          ]
        }
      ]
    },
    {
      name: 'Peaky Blinders',
      ref: 'peaky-blinders',
      seasons: [
        {
          number: 4,
          episodes: [
            {
              number: 1,
              date: '11/16/2018'
            },
            {
              number: 2,
              date: '11/23/2018'
            },
            {
              number: 3,
              date: '11/30/2018'
            },
            {
              number: 4,
              date: '12/07/2018'
            },
            {
              number: 5,
              date: '12/14/2018'
            },
            {
              number: 6,
              date: '12/21/2018'
            }
          ]
        }
      ]
    },
    {
      name: 'Burger Quizz',
      ref: 'burger-quizz',
      seasons: [
        {
          number: 2,
          episodes: [
            {
              number: 22,
              date: '09/05/2018'
            },
            {
              number: 23,
              date: '09/05/2018'
            },
            {
              number: 24,
              date: '09/12/2018'
            },
            {
              number: 25,
              date: '09/12/2018'
            },
            {
              number: 26,
              date: '09/19/2018'
            },
            {
              number: 27,
              date: '09/19/2018'
            },
            {
              number: 28,
              date: '09/26/2018'
            },
            {
              number: 29,
              date: '09/26/2018'
            },
            {
              number: 30,
              date: '10/03/2018'
            },
            {
              number: 31,
              date: '10/03/2018'
            },
            {
              number: 32,
              date: '10/10/2018'
            },
            {
              number: 33,
              date: '10/10/2018'
            }
          ]
        }
      ]
    }
  ]
}

var listOfSeries = $(".series");
for(var i = 0; i < tvShows.series.length; i++){
  var liSerie = $("<li class='serie-name " + tvShows.series[i].ref + "'></li>").text(tvShows.series[i].name);
  listOfSeries.append(liSerie);
}



tvShows.series.forEach(function(serie){
  serie.seasons.forEach(function(season){
    season.episodes.forEach(function(episode){
      var data_dates = episode.date.split('/');
      var divMonthEpisode = $("div").filter("[data-month=" + (Number(data_dates[0]) - 1) + "]").filter("[data-year=" + Number(data_dates[2]) + "]");
      if(divMonthEpisode[0] !== undefined){
        var divDayEpisode = divMonthEpisode.find("div").filter(".day").filter("[data-day=" + Number(data_dates[1]) + "]");
        var divEpisodeToPut = $("<div class='episode' data-serie='" + serie.ref + "' title=\"" + serie.name + "\"></div> ");
        divEpisodeToPut.text(serie.name + " - S" + ((season.number < 10) ? "0" + season.number : season.number) + "E" + ((episode.number < 10) ? "0" + episode.number : episode.number));
        divDayEpisode.append(divEpisodeToPut);
      }
    });
  });
});


/* Exercice n°3 */
var divCalMonths = $("div[class='cal-month']");
var monthList = $("ul[class='months']").children();
for(var i = 0; i < 6; i++){
  var anchor = months[divCalMonths.eq(i).attr("data-month")] + divCalMonths.eq(i).attr("data-year");
  divCalMonths.eq(i).attr("id", anchor);
  var monthString = monthList.eq(i).html();
  monthList.eq(i).html("");
  monthList.eq(i)
  .append(
    $("<a></a>")
    .attr("href", "#" + anchor)
    .text(monthString)
  );
}

$("div[class='episode']").css({display: "none"}); /* Cache tous les épisodes */

$(".series li").css({color: "rgb(100, 100, 100)"}); /* Donne une couleur grisatre à la série quand elle n'est pas sélectionnée dans la liste */

function displayEpisodes(classe){ /*Pas de checkbox mais possibilité d'afficher la ou les séries souhaitées, en les sélectionnant dans la liste */
  $("div[data-serie='" + classe + "']").css({display: "block"});
}

function hideEpisodes(classe){
  $("div[data-serie='" + classe + "']").css({display: "none"});
}

$(".series").on('click', "li", function(){ /* S'occupe de l'événement au clic sur les séries et appelle les fonctions qui affichent les épisodes des séries sélectionnées */
  if($(this).css("color") === "rgb(100, 100, 100)"){
    $(this).css("color", "rgb(51, 51, 51)");
    var classes = $(this).attr("class").split(' ');
    displayEpisodes(classes[1]);
  }
  else{
    $(this).css("color", "rgb(100, 100, 100)");
    hideEpisodes($(this).attr("class").split(' ')[1]);
  }
});
/*Add today and yesterday classes */
var todayDate = new Date();
var divCurrentMonth = $("div[class='cal-month']").filter("[data-month='" + todayDate.getMonth() + "']");
var divToday = divCurrentMonth.find("div[data-day='" + todayDate.getDate() + "']");
var divsYesterday = divCurrentMonth.find("div[data-day]:lt(" + (todayDate.getDate() - 1) + ")");
divToday.addClass("today");
divsYesterday.addClass("past");

var picturesLinks = {
  series: [
    {
      name: "Better Call Saul",
      picture: "https://upload.wikimedia.org/wikipedia/fr/thumb/a/aa/Better_Call_Saul_-_Logo_3.svg/260px-Better_Call_Saul_-_Logo_3.svg.png"
    },
    {
      name: "Marvel's Daredevil",
      picture: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Daredevil_Logo.svg/330px-Daredevil_Logo.svg.png"
    }
  ]
}

$("div[class='episode']").dblclick(function(){ /* Event double clic */
  var container = $("<div class='container'></div>");
  var name = $(this).attr("title");
  if($(this).find("div").length === 0){
    $(this).append(container);
    picturesLinks.series.forEach(function(serie){
      if(serie.name === name){
        container.append($("<img alt=\"" + name + "\" src='" + serie.picture + "'>"));
        container[0].addEventListener("dblclick", function(e){
          this.remove();
          e.stopPropagation();
        });
      }
    });
  }
});
