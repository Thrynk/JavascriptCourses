const fizzbuzzService = require("./fizzbuzz");

describe("Fizzbuzz Service", function(){
  it("returns an empty string if no number provided", function(){
    expect(fizzbuzzService.fizzbuzz()).toBe("");
  });

  it("returns fizz if called with 42", function(){
    expect(fizzbuzzService.fizzbuzz(42)).toBe("fizz");
  });

  it("returns buzz if called with 5", function(){
    expect(fizzbuzzService.fizzbuzz(5)).toBe("buzz");
  });

  it("returns fizzbuzz if called with 15", function(){
    expect(fizzbuzzService.fizzbuzz(15)).toBe("fizzbuzz");
  });

  it("returns 7 if called with 7", function(){
    expect(fizzbuzzService.fizzbuzz(7)).toBe("7");
  });

  it("returns fizzfizz if called with 9", function(){
    expect(fizzbuzzService.fizzbuzz(9)).toBe("fizzfizz");
  });

  it("returns fizzbuzzfizzbuzzbuzz if called with 9000", function(){
    expect(fizzbuzzService.fizzbuzz(9000)).toBe("fizzbuzzfizzbuzzbuzz");
  });
});
