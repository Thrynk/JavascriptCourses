(function(){

  var goodAnswerIndex = -1;

  var score = 0;

  function shuffle(a) { /* Shuffle an array */
    var j, x, i;
    for (i = a.length - 1; i > 0; i--) {
        j = Math.floor(Math.random() * (i + 1));
        x = a[i];
        a[i] = a[j];
        a[j] = x;
    }
    return a;
  }

  function insertNainAndAnswers(nains){

    var randomNumber = Math.floor(Math.random() * nains.length);

    var randomNumberForAnswer = Math.floor(Math.random() * 4);

    goodAnswerIndex = randomNumber;

    var mainImg = document.getElementsByClassName("mainImg")[0];
    mainImg.setAttribute("src", nains[randomNumber].url);
    mainImg.setAttribute("alt", nains[randomNumber].name);

    var goodAnswer = document.getElementById("answer" + randomNumberForAnswer);
    goodAnswer.innerText = nains[randomNumber].name;
    var nainsShuffled = new Array().concat(nains);
    nainsShuffled = shuffle(nainsShuffled);
    var indexNainRandom = 0;
    for(var i = 0; i < 4; i++){
      if(i !== randomNumberForAnswer){
        var answer = document.getElementById("answer" + i);
        if(nainsShuffled[indexNainRandom].name !== nains[randomNumber].name){
          //insert alea nain
          answer.innerText = nainsShuffled[indexNainRandom].name;
        }
        else{ /*Pour garder le bon numéro pour answer on désincrémente de 1 i */
          i--;
        }
        indexNainRandom++;
      }
    }
  }

  fetch("/dwarfs").then(function(response){
    return response.json();
  }).then(function(data){
    nains = data.nains;
    insertNainAndAnswers(nains);

    var buttons = document.getElementsByTagName("button");
    for(var i = 0; i < buttons.length; i++){
      buttons[i].addEventListener("click", function(event){
        if(event.currentTarget.childNodes[1].innerText === nains[goodAnswerIndex].name){
          score++;
          console.log(score);
        }
        document.getElementsByClassName("currentQuestion")[0].innerText = Number(document.getElementsByClassName("currentQuestion")[0].innerText) + 1;
        insertNainAndAnswers(nains);
      });
    }
  });
})();
