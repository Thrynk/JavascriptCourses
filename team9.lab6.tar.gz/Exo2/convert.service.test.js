const convertService = require('./convert.service');
const changeRateService = require('./change-rate.service');

describe("convert service", function(){
  changeRateService.getChangeRate = jest.fn(function(sourceCurrency, destinationCurrency){
    return Promise.resolve(1.12);
  });
  it('returns amount in destination currency if called with good parameters', function(){
    expect.assertions(1);
    return expect(convertService.convert(1, "EUR", "GBP")).resolves.toBe(1.12);
  });
  it('returns Amount should be a number if called wrong parameter', function(){
    expect.assertions(1);
    return expect(convertService.convert("A")).rejects.toMatch("Amount should be a number");
  });

});
